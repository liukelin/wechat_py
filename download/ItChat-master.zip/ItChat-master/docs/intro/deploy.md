# 部署

## Windows系统

直接运行即可。

## Linux系统

若需要后台命令行运行可以：
```bash
nohup python run.py &
```

之后手动打开二维码扫描或者使用[一些方式](https://github.com/littlecodersh/EasierLife/tree/master/Plugins/QRCode)让二维码在命令行显示。
